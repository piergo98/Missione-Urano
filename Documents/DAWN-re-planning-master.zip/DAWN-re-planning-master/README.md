# RAS_DAWN

Repo for the Aerospace robotics project DAWN

To run the program it suffices to run the script entire_mission.m

To see some animations of the mission two scripts have been generated: run animation_close_by.m to see the animation of each close by, run animation_solar_system.m to see the animation of the spacecraft wandering through the solar system.

# --------------------------------------------------

Repo per il progetto di robotica aerospaziale DAWN

Per avviare il programma basta eseguire il file entire_mission.m

Sono stati generati due script per le animazioni. In animation_close_by.m vengono mostrati i vari close by, mentre in animation_solar_system.m viene animato la sonda che viaggia nel sistema solare.