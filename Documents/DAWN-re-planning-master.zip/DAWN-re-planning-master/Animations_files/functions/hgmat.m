function T = hgmat(rot, vett)

T = [rot, vett; 0 0 0 1];

end